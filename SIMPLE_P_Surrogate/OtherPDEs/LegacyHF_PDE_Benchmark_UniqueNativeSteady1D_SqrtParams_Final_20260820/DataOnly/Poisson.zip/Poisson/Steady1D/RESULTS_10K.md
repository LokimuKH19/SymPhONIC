# Poisson / Steady1D / DataOnly - 10K rerun

- Profile: baseline
- Epochs: 1200
- Device: CUDA
- Training mode: Data-only optimization; the PDE residual is diagnostic only.
- Boundary/initial data: exact hard projection; no boundary loss.
- Error and residual summaries below use every point in the saved field archive.

Best field result: **HF_CFNO** with test relative L2 **0.1711**.

| Model | Params | Best epoch | Test rel. L2 | PDE MSE | Mean abs. error | Max abs. error | Mean abs. residual | Max abs. residual | 10K/700 rel. L2 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| FNO | 10007 | 1200 | 0.2485 | 1.4032 | 0.0804 | 0.2025 | 65.3789 | 365.6438 | 0.633 |
| CFNO | 10029 | 97 | 0.3892 | 0.2905 | 0.3594 | 0.5804 | 36.0793 | 86.8085 | 0.768 |
| HF-FNO | 10003 | 1199 | 0.1867 | 1.3433 | 0.0935 | 0.3286 | 73.7196 | 350.8459 | 0.424 |
| HF-CFNO | 10029 | 1193 | 0.1711 | 2.2726 | 0.0799 | 0.2297 | 70.0369 | 288.8756 | 0.528 |

The directory also contains individual normalized and absolute loss curves, prediction/reference/error plots, PDE-residual plots, Fourier-error plots, and four-model comparison figures.

See the root PARAMETER_SCALE_10K_SUMMARY.md for the cross-case interpretation.
